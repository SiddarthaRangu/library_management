let searchInputEl = document.getElementById("searchInput");
let searchResultsEl = document.getElementById("searchResults");
let spinnerEl = document.getElementById("spinner");

function createAndppendSearchResults(result) {

    let resultItemEl = document.createElement("div");
    resultItemEl.classList.add("result-item");
    searchResultsEl.appendChild(resultItemEl);

    let author = result.author;
    let imageLink = result.imageLink;
    let resultEl = document.createElement("div");
    resultEl.classList.add("d-flex");
    let AuthorEl = document.createElement("p");
    AuthorEl.textContent = author;
    resultItemEl.appendChild(AuthorEl);
    AuthorEl.classList.add("result-title", "order-2");
    let imageEl = document.createElement("img");
    imageEl.setAttribute("src", imageLink);
    resultEl.appendChild(imageEl);
    imageEl.classList.add("result-image", "col-6", "col-md-3");
    searchResultsEl.appendChild(resultEl);


}

function displayResults(searchResults) {
    spinnerEl.classList.add("d-none");
    for (let result of searchResults) {
        createAndppendSearchResults(result);
    }
    let head = document.createElement("h1");
    searchResultsEl.appendChild(head);

}

function searchBooks(event) {
    if (event.key === "Enter") {
        let searchInputValue = searchInputEl.value;
        let url = "https://apis.ccbp.in/book-store?title=" + searchInputValue;
        let options = {
            method: "GET"
        };
        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsonData) {
                let {
                    search_results
                } = jsonData;
                displayResults(search_results);
            });
    }

}


searchInputEl.addEventListener("keydown", searchBooks);